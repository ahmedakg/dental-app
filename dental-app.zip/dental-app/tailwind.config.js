/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fff4ed',
          100: '#ffe6d5',
          200: '#ffc9aa',
          300: '#ffa574',
          400: '#ff6b35',
          500: '#fe5518',
          600: '#ef3b0e',
          700: '#c6280e',
          800: '#9d2214',
          900: '#7e1e14',
        },
        tangerine: {
          DEFAULT: '#ff6b35',
          light: '#ffa574',
          dark: '#ef3b0e'
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
