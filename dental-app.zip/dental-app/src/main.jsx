import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { initializeDefaultData } from './db/indexedDB'

// Initialize database with default data
initializeDefaultData().then(() => {
  console.log('✅ Database initialized')
}).catch(err => {
  console.error('❌ Database initialization failed:', err)
})

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
