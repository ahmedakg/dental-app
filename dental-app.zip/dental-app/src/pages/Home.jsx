export default function Home() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold mb-2">Today's Appointments</h3>
          <p className="text-4xl font-bold text-tangerine">0</p>
        </div>
        <div className="card">
          <h3 className="text-lg font-semibold mb-2">Total Patients</h3>
          <p className="text-4xl font-bold text-tangerine">0</p>
        </div>
        <div className="card">
          <h3 className="text-lg font-semibold mb-2">Monthly Revenue</h3>
          <p className="text-4xl font-bold text-tangerine">Rs. 0</p>
        </div>
      </div>
    </div>
  )
}
