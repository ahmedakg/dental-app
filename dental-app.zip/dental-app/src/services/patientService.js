import db from '../db/indexedDB';
import { v4 as uuidv4 } from 'uuid';

// Get all patients
export const getAllPatients = async () => {
  try {
    const patients = await db.patients.orderBy('name').toArray();
    return patients;
  } catch (error) {
    console.error('Error fetching patients:', error);
    throw error;
  }
};

// Get patient by ID
export const getPatientById = async (id) => {
  try {
    const patient = await db.patients.get(id);
    return patient;
  } catch (error) {
    console.error('Error fetching patient:', error);
    throw error;
  }
};

// Search patients by name or phone
export const searchPatients = async (searchTerm) => {
  try {
    const term = searchTerm.toLowerCase();
    const patients = await db.patients
      .filter(patient => 
        patient.name.toLowerCase().includes(term) ||
        patient.phone.includes(term)
      )
      .toArray();
    return patients;
  } catch (error) {
    console.error('Error searching patients:', error);
    throw error;
  }
};

// Add new patient
export const addPatient = async (patientData) => {
  try {
    const newPatient = {
      ...patientData,
      uniqueId: `PAT-${Date.now()}`,
      status: 'active',
      totalPaid: 0,
      totalOwed: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastVisit: null
    };
    
    const id = await db.patients.add(newPatient);
    return { ...newPatient, id };
  } catch (error) {
    console.error('Error adding patient:', error);
    throw error;
  }
};

// Update patient
export const updatePatient = async (id, updates) => {
  try {
    await db.patients.update(id, {
      ...updates,
      updatedAt: new Date()
    });
    return await getPatientById(id);
  } catch (error) {
    console.error('Error updating patient:', error);
    throw error;
  }
};

// Delete patient (soft delete)
export const deletePatient = async (id) => {
  try {
    await db.patients.update(id, {
      status: 'archived',
      updatedAt: new Date()
    });
    return true;
  } catch (error) {
    console.error('Error deleting patient:', error);
    throw error;
  }
};

// Get patient statistics
export const getPatientStats = async (patientId) => {
  try {
    const visits = await db.visits.where('patientId').equals(patientId).toArray();
    const payments = await db.payments.where('patientId').equals(patientId).toArray();
    
    const totalPaid = payments.reduce((sum, payment) => sum + payment.amount, 0);
    const totalCost = visits.reduce((sum, visit) => sum + (visit.finalAmount || 0), 0);
    const totalOwed = totalCost - totalPaid;
    
    return {
      totalVisits: visits.length,
      totalPaid,
      totalCost,
      totalOwed,
      lastVisit: visits.length > 0 ? visits[visits.length - 1].visitDate : null
    };
  } catch (error) {
    console.error('Error fetching patient stats:', error);
    throw error;
  }
};

// Update patient balance
export const updatePatientBalance = async (patientId) => {
  try {
    const stats = await getPatientStats(patientId);
    await db.patients.update(patientId, {
      totalPaid: stats.totalPaid,
      totalOwed: stats.totalOwed,
      lastVisit: stats.lastVisit,
      updatedAt: new Date()
    });
  } catch (error) {
    console.error('Error updating patient balance:', error);
    throw error;
  }
};
