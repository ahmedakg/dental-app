import Dexie from 'dexie';

// Initialize IndexedDB database
const db = new Dexie('AbdullahDentalDB');

// Define database schema
db.version(1).stores({
  // Core collections
  patients: '++id, name, phone, &uniqueId, status, createdAt',
  appointments: '++id, date, patientId, type, status',
  visits: '++id, patientId, visitDate',
  treatments: '++id, category, name, isActive',
  payments: '++id, patientId, visitId, paymentDate',
  labWork: '++id, patientId, dateSent, status',
  orthodontic: '++id, patientId, status',
  reminders: '++id, patientId, scheduledDate, status, type',
  expenses: '++id, category, date, month',
  settings: 'id'
});

// Initialize default data
export const initializeDefaultData = async () => {
  try {
    // Check if settings exist
    const settings = await db.settings.get('clinic-settings');
    
    if (!settings) {
      console.log('Initializing default settings...');
      await db.settings.add({
        id: 'clinic-settings',
        clinicName: 'Abdullah Dental Care',
        doctorName: 'Dr. Ahmed Abdullah',
        pmcNumber: '',
        qualifications: 'BDS',
        address: '37-G4, Qasim Ave., Phase 2, Hayatabad, Peshawar',
        phone: '+92-334-5822-622',
        email: '',
        usdPkrRate: 280,
        lastRateUpdate: new Date(),
        nextBiannualUpdate: calculateNextBiannualUpdate(),
        receiptPrefix: 'ADCR',
        currentReceiptNumber: 1,
        createdAt: new Date()
      });
    }
    
    // Load default treatment menu if empty
    const treatmentCount = await db.treatments.count();
    if (treatmentCount === 0) {
      console.log('Loading default treatment menu...');
      await loadDefaultTreatments();
    }
    
    console.log('Database initialized successfully');
    return true;
  } catch (error) {
    console.error('Error initializing database:', error);
    return false;
  }
};

// Calculate next biannual update date (May 1 or Nov 1)
function calculateNextBiannualUpdate() {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  
  if (currentMonth < 4) {
    return new Date(currentYear, 4, 1); // May 1 this year
  } else if (currentMonth < 10) {
    return new Date(currentYear, 10, 1); // Nov 1 this year
  } else {
    return new Date(currentYear + 1, 4, 1); // May 1 next year
  }
}

// Load default 70 treatments
const loadDefaultTreatments = async () => {
  const treatments = [
    // CONSULTATION & DIAGNOSTICS
    { category: 'consultation', name: 'Consultation', baseUSD: 7.14, basePKR: 2000, pricingType: 'fixed', displayOrder: 1, isActive: true },
    { category: 'consultation', name: 'Periapical X-Ray', baseUSD: 3.57, basePKR: 1000, pricingType: 'per-tooth', displayOrder: 2, isActive: true },
    { category: 'consultation', name: 'Post-Op Follow-up', baseUSD: 3.57, basePKR: 1000, pricingType: 'fixed', displayOrder: 3, isActive: true },
    
    // PREVENTIVE
    { category: 'preventive', name: 'Pits & Fissure Sealants', baseUSD: 17.86, basePKR: 5000, pricingType: 'per-tooth', displayOrder: 4, isActive: true },
    { category: 'preventive', name: 'Fluoride Application (Children)', baseUSD: 7.14, basePKR: 2000, pricingType: 'fixed', displayOrder: 5, isActive: true },
    { category: 'preventive', name: 'Night Guard Single Arch', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-jaw', displayOrder: 6, isActive: true },
    { category: 'preventive', name: 'Athletic Mouthguards', baseUSD: 28.57, basePKR: 8000, pricingType: 'fixed', displayOrder: 7, isActive: true },
    
    // FILLINGS
    { category: 'fillings', name: 'Temporary Filling', baseUSD: 14.29, basePKR: 4000, pricingType: 'per-tooth', displayOrder: 8, isActive: true },
    { category: 'fillings', name: 'Glass Ionomer Fluoride', baseUSD: 17.86, basePKR: 5000, pricingType: 'per-tooth', displayOrder: 9, isActive: true },
    { category: 'fillings', name: 'Light Cure Composite (A) Class I & V', baseUSD: 28.57, basePKR: 8000, pricingType: 'per-tooth', displayOrder: 10, isActive: true },
    { category: 'fillings', name: 'Light Cure Composite (B) Class II, III, IV', baseUSD: 28.57, basePKR: 8000, pricingType: 'per-tooth', displayOrder: 11, isActive: true },
    { category: 'fillings', name: 'Amalgam/Cermet Silver', baseUSD: 17.86, basePKR: 5000, pricingType: 'per-tooth', displayOrder: 12, isActive: true },
    { category: 'fillings', name: 'Inlays/Onlays Composite', baseUSD: 42.86, basePKR: 12000, pricingType: 'per-tooth', displayOrder: 13, isActive: true },
    
    // POST & CORE
    { category: 'restorative', name: 'Fibre Post & Core Buildup', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-tooth', displayOrder: 14, isActive: true },
    
    // PERIODONTICS
    { category: 'periodontics', name: 'Scaling W/O Polish', baseUSD: 28.57, basePKR: 8000, pricingType: 'fixed', displayOrder: 15, isActive: true },
    { category: 'periodontics', name: 'Scaling + Polishing', baseUSD: 35.71, basePKR: 10000, pricingType: 'fixed', displayOrder: 16, isActive: true },
    { category: 'periodontics', name: 'Deep Scaling', baseUSD: 71.43, basePKR: 20000, pricingType: 'fixed', displayOrder: 17, isActive: true },
    { category: 'periodontics', name: 'Gingivectomy per Quadrant', baseUSD: 28.57, basePKR: 8000, pricingType: 'fixed', displayOrder: 18, isActive: true },
    { category: 'periodontics', name: 'Flap Surgery per Quadrant', baseUSD: 53.57, basePKR: 15000, pricingType: 'fixed', displayOrder: 19, isActive: true },
    { category: 'periodontics', name: 'Desensitization Treatment', baseUSD: 10.71, basePKR: 3000, pricingType: 'fixed', displayOrder: 20, isActive: true },
    
    // ENDODONTICS
    { category: 'endodontics', name: 'Root Canal Therapy (RCT)', baseUSD: 53.57, basePKR: 15000, pricingType: 'per-tooth', displayOrder: 21, isActive: true },
    { category: 'endodontics', name: 'Pulpectomy', baseUSD: 28.57, basePKR: 8000, pricingType: 'per-tooth', displayOrder: 22, isActive: true },
    { category: 'endodontics', name: 'Apicectomy', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-tooth', displayOrder: 23, isActive: true },
    
    // ORAL SURGERY
    { category: 'surgery', name: 'Extraction Deciduous', baseUSD: 14.29, basePKR: 4000, pricingType: 'per-tooth', displayOrder: 24, isActive: true },
    { category: 'surgery', name: 'Extraction (A) Simple', baseUSD: 17.86, basePKR: 5000, pricingType: 'per-tooth', displayOrder: 25, isActive: true },
    { category: 'surgery', name: 'Extraction (B) Complicated', baseUSD: 28.57, basePKR: 8000, pricingType: 'per-tooth', displayOrder: 26, isActive: true },
    { category: 'surgery', name: 'Extraction (C) Surgical', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-tooth', displayOrder: 27, isActive: true },
    { category: 'surgery', name: 'Impacted Tooth Removal', baseUSD: 71.43, basePKR: 20000, pricingType: 'per-tooth', displayOrder: 28, isActive: true },
    { category: 'surgery', name: 'Alveoplasty', baseUSD: 28.57, basePKR: 8000, pricingType: 'per-jaw', displayOrder: 29, isActive: true },
    { category: 'surgery', name: 'Operculectomy', baseUSD: 17.86, basePKR: 5000, pricingType: 'fixed', displayOrder: 30, isActive: true },
    { category: 'surgery', name: 'Frenectomy', baseUSD: 21.43, basePKR: 6000, pricingType: 'fixed', displayOrder: 31, isActive: true },
    { category: 'surgery', name: 'Biopsy', baseUSD: 35.71, basePKR: 10000, pricingType: 'fixed', displayOrder: 32, isActive: true },
    { category: 'surgery', name: 'Cyst Enucleation', baseUSD: 53.57, basePKR: 15000, pricingType: 'fixed', displayOrder: 33, isActive: true },
    
    // PROSTHESIS - CROWNS
    { category: 'prosthesis', name: 'Crown Metal', baseUSD: 28.57, basePKR: 8000, pricingType: 'per-tooth', displayOrder: 34, isActive: true },
    { category: 'prosthesis', name: 'Crown PFM Classic', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-tooth', displayOrder: 35, isActive: true },
    { category: 'prosthesis', name: 'Crown PFM Japanese', baseUSD: 53.57, basePKR: 15000, pricingType: 'per-tooth', displayOrder: 36, isActive: true },
    { category: 'prosthesis', name: 'Crown Full Zirconia', baseUSD: 64.29, basePKR: 18000, pricingType: 'per-tooth', displayOrder: 37, isActive: true },
    { category: 'prosthesis', name: 'Crown E-Max', baseUSD: 85.71, basePKR: 24000, pricingType: 'per-tooth', displayOrder: 38, isActive: true },
    { category: 'prosthesis', name: 'Crown Layered Zirconia', baseUSD: 107.14, basePKR: 30000, pricingType: 'per-tooth', displayOrder: 39, isActive: true },
    
    // PROSTHESIS - BRIDGES
    { category: 'prosthesis', name: 'Bridge 3 Unit PFM Classic', baseUSD: 107.14, basePKR: 30000, pricingType: 'fixed', displayOrder: 40, isActive: true },
    { category: 'prosthesis', name: 'Bridge 3 Unit PFM Japanese', baseUSD: 160.71, basePKR: 45000, pricingType: 'fixed', displayOrder: 41, isActive: true },
    { category: 'prosthesis', name: 'Bridge 3 Unit Zirconia', baseUSD: 214.29, basePKR: 60000, pricingType: 'fixed', displayOrder: 42, isActive: true },
    
    // PROSTHESIS - DENTURES
    { category: 'prosthesis', name: 'Complete Denture Single Arch', baseUSD: 71.43, basePKR: 20000, pricingType: 'per-jaw', displayOrder: 43, isActive: true },
    { category: 'prosthesis', name: 'Complete Denture Both Arches', baseUSD: 142.86, basePKR: 40000, pricingType: 'fixed', displayOrder: 44, isActive: true },
    { category: 'prosthesis', name: 'Partial Denture Acrylic', baseUSD: 53.57, basePKR: 15000, pricingType: 'per-jaw', displayOrder: 45, isActive: true },
    { category: 'prosthesis', name: 'Partial Denture Cast Partial', baseUSD: 107.14, basePKR: 30000, pricingType: 'per-jaw', displayOrder: 46, isActive: true },
    { category: 'prosthesis', name: 'Flexible Partial Denture', baseUSD: 89.29, basePKR: 25000, pricingType: 'per-jaw', displayOrder: 47, isActive: true },
    { category: 'prosthesis', name: 'Denture Reline', baseUSD: 21.43, basePKR: 6000, pricingType: 'per-jaw', displayOrder: 48, isActive: true },
    { category: 'prosthesis', name: 'Denture Repair', baseUSD: 14.29, basePKR: 4000, pricingType: 'fixed', displayOrder: 49, isActive: true },
    
    // IMPLANTS
    { category: 'implants', name: 'Implant Fixture Placement', baseUSD: 357.14, basePKR: 100000, pricingType: 'per-tooth', displayOrder: 50, isActive: true },
    { category: 'implants', name: 'Implant Abutment', baseUSD: 71.43, basePKR: 20000, pricingType: 'per-tooth', displayOrder: 51, isActive: true },
    { category: 'implants', name: 'Implant Crown', baseUSD: 107.14, basePKR: 30000, pricingType: 'per-tooth', displayOrder: 52, isActive: true },
    { category: 'implants', name: 'Bone Grafting', baseUSD: 178.57, basePKR: 50000, pricingType: 'per-tooth', displayOrder: 53, isActive: true },
    { category: 'implants', name: 'Sinus Lift', baseUSD: 214.29, basePKR: 60000, pricingType: 'per-jaw', displayOrder: 54, isActive: true },
    
    // ORTHODONTICS
    { category: 'orthodontics', name: 'Braces Metal (Both Arches)', baseUSD: 428.57, basePKR: 120000, pricingType: 'fixed', displayOrder: 55, isActive: true },
    { category: 'orthodontics', name: 'Braces Ceramic (Both Arches)', baseUSD: 535.71, basePKR: 150000, pricingType: 'fixed', displayOrder: 56, isActive: true },
    { category: 'orthodontics', name: 'Braces Self-Ligating', baseUSD: 642.86, basePKR: 180000, pricingType: 'fixed', displayOrder: 57, isActive: true },
    { category: 'orthodontics', name: 'Invisalign/Clear Aligners', baseUSD: 1071.43, basePKR: 300000, pricingType: 'fixed', displayOrder: 58, isActive: true },
    { category: 'orthodontics', name: 'Retainers (Both Arches)', baseUSD: 71.43, basePKR: 20000, pricingType: 'fixed', displayOrder: 59, isActive: true },
    { category: 'orthodontics', name: 'Orthodontic Adjustment', baseUSD: 10.71, basePKR: 3000, pricingType: 'fixed', displayOrder: 60, isActive: true },
    
    // PEDIATRIC DENTISTRY
    { category: 'pediatric', name: 'Pulpotomy', baseUSD: 21.43, basePKR: 6000, pricingType: 'per-tooth', displayOrder: 61, isActive: true },
    { category: 'pediatric', name: 'Stainless Steel Crown (Pediatric)', baseUSD: 17.86, basePKR: 5000, pricingType: 'per-tooth', displayOrder: 62, isActive: true },
    { category: 'pediatric', name: 'Space Maintainer', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-jaw', displayOrder: 63, isActive: true },
    
    // COSMETIC
    { category: 'cosmetic', name: 'Teeth Whitening (In-Office)', baseUSD: 142.86, basePKR: 40000, pricingType: 'fixed', displayOrder: 64, isActive: true },
    { category: 'cosmetic', name: 'Teeth Whitening (Home Kit)', baseUSD: 71.43, basePKR: 20000, pricingType: 'fixed', displayOrder: 65, isActive: true },
    { category: 'cosmetic', name: 'Veneers Composite', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-tooth', displayOrder: 66, isActive: true },
    { category: 'cosmetic', name: 'Veneers Porcelain', baseUSD: 107.14, basePKR: 30000, pricingType: 'per-tooth', displayOrder: 67, isActive: true },
    { category: 'cosmetic', name: 'Smile Makeover (Full Mouth)', baseUSD: 2142.86, basePKR: 600000, pricingType: 'fixed', displayOrder: 68, isActive: true },
    
    // EMERGENCY
    { category: 'emergency', name: 'Emergency Pain Relief', baseUSD: 10.71, basePKR: 3000, pricingType: 'fixed', displayOrder: 69, isActive: true },
    { category: 'emergency', name: 'Tooth Splinting', baseUSD: 35.71, basePKR: 10000, pricingType: 'per-tooth', displayOrder: 70, isActive: true }
  ];
  
  await db.treatments.bulkAdd(treatments);
};

export default db;
