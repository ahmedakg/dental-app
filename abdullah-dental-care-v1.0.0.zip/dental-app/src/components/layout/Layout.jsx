import { Link } from 'react-router-dom'

export default function Layout({ children }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-tangerine text-white p-4">
        <div className="container mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold">Abdullah Dental Care</h1>
          <nav className="flex gap-4">
            <Link to="/" className="hover:underline">Dashboard</Link>
            <Link to="/patients" className="hover:underline">Patients</Link>
            <Link to="/appointments" className="hover:underline">Appointments</Link>
            <Link to="/settings" className="hover:underline">Settings</Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 container mx-auto">
        {children}
      </main>
    </div>
  )
}
