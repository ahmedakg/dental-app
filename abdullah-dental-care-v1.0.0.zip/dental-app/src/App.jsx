import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Layout from './components/layout/Layout'
import Home from './pages/Home'
import Patients from './pages/Patients'
import Appointments from './pages/Appointments'
import Treatments from './pages/Treatments'
import Billing from './pages/Billing'
import LabWork from './pages/LabWork'
import Orthodontic from './pages/Orthodontic'
import Reports from './pages/Reports'
import Settings from './pages/Settings'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/patients" element={<Patients />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/treatments" element={<Treatments />} />
          <Route path="/billing" element={<Billing />} />
          <Route path="/lab" element={<LabWork />} />
          <Route path="/orthodontic" element={<Orthodontic />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </Layout>
      <Toaster position="top-right" />
    </Router>
  )
}

export default App
