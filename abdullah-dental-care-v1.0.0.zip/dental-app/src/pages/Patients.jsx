export default function Patients() {
  return <div className="p-6"><h1 className="text-3xl font-bold">Patients</h1></div>
}
