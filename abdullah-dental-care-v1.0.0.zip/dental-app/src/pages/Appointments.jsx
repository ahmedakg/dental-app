export default function Appointments() {
  return <div className="p-6"><h1 className="text-3xl font-bold">Appointments</h1></div>
}
