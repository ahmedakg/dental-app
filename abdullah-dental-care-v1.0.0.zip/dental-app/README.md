# 🦷 Abdullah Dental Care - Complete Clinic Management System

**Version 1.0.0 - 100% FREE FOREVER**

A complete dental clinic management system built with React. **No subscriptions, no fees, your data stays with you.**

## ✨ Features

- 👥 **Patient Management** - Complete records with medical history
- 📅 **Appointment Calendar** - Separate calendars for General & Orthodontic
- 🦷 **Treatment Planning** - FDI tooth charts, 70 pre-loaded treatments
- 💰 **Billing & Payments** - Professional PDF receipts
- 🔬 **Lab Work Tracking** - Track cases sent to labs
- 🦷 **Orthodontic Module** - Braces patients, installments, profit split
- 📊 **Reports & Analytics** - Revenue, expenses, treatment analytics
- 📱 **WhatsApp Reminders** - OS share integration
- 💾 **Google Drive Backup** - Optional cloud backup
- 🌐 **100% Offline** - Works without internet
- 📱 **PWA Support** - Install on Android/iOS

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

## 📖 Documentation

See `BUILD_INSTRUCTIONS.md` for complete setup, deployment, and usage guide.

## 🔐 Data Privacy

- All data stored locally in your browser (IndexedDB)
- No external servers required
- Optional Google Drive backup
- Your data belongs to you forever

## 📄 License

Free for personal and commercial use. No attribution required.

**Made with ❤️ for Abdullah Dental Care, Peshawar**
