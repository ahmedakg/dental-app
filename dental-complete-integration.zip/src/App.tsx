// Main App Component - Integrates All 8 Modules
import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import './styles/app.css';

// Module placeholders - Replace with actual imports when modules are added
const ModulePlaceholder = ({ moduleName }: { moduleName: string }) => (
  <div className="module-placeholder">
    <div className="placeholder-content">
      <h2>{moduleName} Module</h2>
      <p>This module will be integrated here.</p>
      <div className="placeholder-instructions">
        <h3>Integration Steps:</h3>
        <ol>
          <li>Copy the {moduleName} module files to <code>src/components/{moduleName.toLowerCase()}/</code></li>
          <li>Import the main component in App.tsx</li>
          <li>Replace this placeholder with the actual component</li>
        </ol>
      </div>
      <div className="placeholder-note">
        <strong>Note:</strong> All module files are included in the separate module ZIPs. 
        Extract and copy them to integrate.
      </div>
    </div>
  </div>
);

function App() {
  const [currentModule, setCurrentModule] = useState('dashboard');
  const [userRole, setUserRole] = useState<'doctor' | 'assistant'>('assistant');
  const [userName, setUserName] = useState('Naveed');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Login Component
  const LoginScreen = () => {
    const [selectedRole, setSelectedRole] = useState<'doctor' | 'assistant'>('assistant');
    const [name, setName] = useState('');

    const handleLogin = () => {
      if (!name.trim()) {
        alert('Please enter your name');
        return;
      }
      setUserRole(selectedRole);
      setUserName(name);
      setIsLoggedIn(true);
    };

    return (
      <div className="login-screen">
        <div className="login-container">
          <div className="login-header">
            <h1>🦷 Abdullah Dental Care</h1>
            <p>Management System v2.0</p>
          </div>
          
          <div className="login-form">
            <h2>Sign In</h2>
            
            <div className="form-group">
              <label>Your Name</label>
              <input
                type="text"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
            </div>

            <div className="form-group">
              <label>Role</label>
              <div className="role-selector">
                <button
                  className={`role-option ${selectedRole === 'assistant' ? 'active' : ''}`}
                  onClick={() => setSelectedRole('assistant')}
                >
                  <span className="role-icon">👔</span>
                  <span>Assistant</span>
                </button>
                <button
                  className={`role-option ${selectedRole === 'doctor' ? 'active' : ''}`}
                  onClick={() => setSelectedRole('doctor')}
                >
                  <span className="role-icon">👨‍⚕️</span>
                  <span>Doctor</span>
                </button>
              </div>
            </div>

            <button className="login-button" onClick={handleLogin}>
              Sign In
            </button>

            <div className="quick-login">
              <p>Quick Login:</p>
              <button onClick={() => { setName('Naveed'); setSelectedRole('assistant'); setUserRole('assistant'); setUserName('Naveed'); setIsLoggedIn(true); }}>
                Naveed (Assistant)
              </button>
              <button onClick={() => { setName('Dr. Ahmed'); setSelectedRole('doctor'); setUserRole('doctor'); setUserName('Dr. Ahmed'); setIsLoggedIn(true); }}>
                Dr. Ahmed (Doctor)
              </button>
            </div>
          </div>

          <div className="login-footer">
            <p>Hayatabad, Peshawar, Pakistan</p>
            <p>Built for Dr. Ahmed Abdullah Khan Gandapur</p>
          </div>
        </div>
      </div>
    );
  };

  // Render module based on selection
  const renderModule = () => {
    switch (currentModule) {
      case 'dashboard':
        return <Dashboard userRole={userRole} userName={userName} />;
      
      case 'patients':
        return <ModulePlaceholder moduleName="Patients" />;
        // After integration: return <PatientManagement userRole={userRole} userName={userName} />;
      
      case 'appointments':
        return <ModulePlaceholder moduleName="Appointments" />;
        // After integration: return <AppointmentCalendar userRole={userRole} userName={userName} />;
      
      case 'treatments':
        return <ModulePlaceholder moduleName="Treatments" />;
        // After integration: return <TreatmentPlanning userRole={userRole} userName={userName} />;
      
      case 'prescriptions':
        return <ModulePlaceholder moduleName="Prescriptions" />;
        // After integration: return <PrescriptionSystem userRole={userRole} userName={userName} />;
      
      case 'billing':
        return <ModulePlaceholder moduleName="Billing" />;
        // After integration: return <BillingSystem userRole={userRole} userName={userName} />;
      
      case 'lab':
        return <ModulePlaceholder moduleName="Lab Work" />;
        // After integration: return <LabWorkTracking userRole={userRole} userName={userName} />;
      
      case 'inventory':
        return <ModulePlaceholder moduleName="Inventory" />;
        // After integration: return <InventoryManagement userRole={userRole} userName={userName} />;
      
      case 'expenses':
        return <ModulePlaceholder moduleName="Expenses" />;
        // After integration: return <ExpenseTracking userRole={userRole} userName={userName} />;
      
      default:
        return <Dashboard userRole={userRole} userName={userName} />;
    }
  };

  if (!isLoggedIn) {
    return <LoginScreen />;
  }

  return (
    <div className="app-container">
      <Navigation
        currentModule={currentModule}
        onModuleChange={setCurrentModule}
        userRole={userRole}
        userName={userName}
      />
      
      <main className="main-content">
        <div className="content-header">
          <h1 className="module-title">
            {currentModule.charAt(0).toUpperCase() + currentModule.slice(1)}
          </h1>
          <div className="header-actions">
            <button 
              className="logout-button"
              onClick={() => {
                setIsLoggedIn(false);
                setCurrentModule('dashboard');
              }}
            >
              Logout
            </button>
          </div>
        </div>
        
        <div className="module-container">
          {renderModule()}
        </div>
      </main>
    </div>
  );
}

export default App;
