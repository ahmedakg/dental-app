import React from 'react';
import LabWorkManagement from './components/lab/LabWorkManagement';

function App() {
  return (
    <div className="app">
      <LabWorkManagement />
    </div>
  );
}

export default App;
